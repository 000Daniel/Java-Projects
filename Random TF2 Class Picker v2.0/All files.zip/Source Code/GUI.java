import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUI{

	
	public static void main(String[] args) {
		MyFrame frame = new MyFrame();
	}

}
